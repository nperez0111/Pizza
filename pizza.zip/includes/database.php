<?PHP
$db = new PDO('mysql:host=localhost;dbname=pizza;charset=utf8', 'root', '');
$table="users";
?>